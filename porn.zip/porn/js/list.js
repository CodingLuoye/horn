function  search() {

    var  name = $("#searchName").val();
    var  lunci = $("#lunci").val();
    var  beginDate = $("#beginDate").val();
    var  endDate = $("#endDate").val();
    var Nsearch = {
        name:name,
        lunci:lunci,
        beginData:beginDate,
        endData:endDate,
    }

    $.ajax({
        type: "POST",
        url: "/ns/search",
        data:JSON.stringify(Nsearch),
        dataType: "json",
        success: function(data){

        },
        error:function () {
            
        }
    });


}

function  closed() {
    alert("close");
}