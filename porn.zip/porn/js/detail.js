function  closed() {
    alert("close")
}
function back() {
    alert("back")
}