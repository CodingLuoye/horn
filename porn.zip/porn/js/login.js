function  login() {
    var userId = $("#userId").val();
    var password = $("#password").val();
    console.log(userId + password);
}